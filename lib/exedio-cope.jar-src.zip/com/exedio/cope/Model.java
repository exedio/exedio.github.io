/*
 * Copyright (C) 2004-2009  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import java.io.PrintStream;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import com.exedio.cope.info.ClusterListenerInfo;
import com.exedio.cope.info.ItemCacheInfo;
import com.exedio.cope.info.QueryCacheHistogram;
import com.exedio.cope.info.QueryCacheInfo;
import com.exedio.cope.info.SequenceInfo;
import com.exedio.cope.util.ModificationListener;
import com.exedio.cope.util.Pool;
import com.exedio.cope.util.Properties;
import com.exedio.dsmf.Constraint;
import com.exedio.dsmf.Schema;

public final class Model
{
	private Revisions revisions; // TODO make final
	private final Object reviseLock = new Object();
	
	final Types types;
	private final Date initializeDate;
	private final LinkedList<WeakReference<ModificationListener>> modificationListeners = new LinkedList<WeakReference<ModificationListener>>();
	private int modificationListenersCleared = 0;

	// set by connect
	private final Object connectLock = new Object();
	private ConnectProperties propertiesIfConnected;
	private Database databaseIfConnected;
	private ItemCache itemCacheIfConnected;
	private QueryCache queryCacheIfConnected;
	ClusterSender clusterSender;
	private ClusterListener clusterListener;
	private Date connectDate = null;
	private boolean logTransactions = false;

	private final AtomicLong nextTransactionId = new AtomicLong();
	private volatile long lastTransactionStartDate = Long.MIN_VALUE;
	
	private final HashSet<Transaction> openTransactions = new HashSet<Transaction>();
	private final ThreadLocal<Transaction> boundTransactions = new ThreadLocal<Transaction>();
	
	private volatile long transactionsCommitWithoutConnection = 0;
	private volatile long transactionsCommitWithConnection = 0;
	private volatile long transactionsRollbackWithoutConnection = 0;
	private volatile long transactionsRollbackWithConnection = 0;
	
	public Model(final Type... types)
	{
		this((Revisions)null, types);
	}
	
	public Model(final Revisions revisions, final Type... types)
	{
		this.revisions = revisions;
		this.types = new Types(this, types);
		this.initializeDate = new Date();
	}
	
	public Map<Feature, Feature> getHiddenFeatures()
	{
		return types.getHiddenFeatures();
	}
	
	/**
	 * Connects this model to the database described in the properties.
	 *
	 * @throws IllegalStateException if this model has already been connected.
	 */
	public void connect(final ConnectProperties properties)
	{
		if(properties==null)
			throw new NullPointerException();

		synchronized(connectLock)
		{
			if(this.propertiesIfConnected==null)
			{
				if(this.databaseIfConnected!=null)
					throw new RuntimeException();
				if(this.itemCacheIfConnected!=null)
					throw new RuntimeException();
				if(this.queryCacheIfConnected!=null)
					throw new RuntimeException();
				if(this.clusterSender!=null)
					throw new RuntimeException();
				if(this.clusterListener!=null)
					throw new RuntimeException();
				if(this.connectDate!=null)
					throw new RuntimeException();
		
				// do this at first, to avoid half-connected model if probe connection fails
				final Database db = properties.createDatabase(revisions);
				this.propertiesIfConnected = properties;
				this.databaseIfConnected = db;
				
				types.connect(db);
				
				this.itemCacheIfConnected = new ItemCache(types.concreteTypeList, properties.getItemCacheLimit());
				this.queryCacheIfConnected = new QueryCache(properties.getQueryCacheLimit());
				
				if(db.cluster)
				{
					final Properties.Source context = properties.getContext();
					{
						final String secretS = context.get("cluster.secret");
						if(secretS!=null)
						{
							final int secret;
							try
							{
								secret = Integer.valueOf(secretS);
							}
							catch(NumberFormatException e)
							{
								throw new RuntimeException("cluster.secret must be a valid integer, but was >" + secretS + '<', e);
							}
							final ClusterConfig config = new ClusterConfig(secret, properties);
							this.clusterSender   = new ClusterSender  (config, properties);
							this.clusterListener = new ClusterListener(config, properties, clusterSender, types.concreteTypeCount, itemCacheIfConnected, queryCacheIfConnected);
						}
					}
				}
				
				this.logTransactions = properties.getTransactionLog();
				this.connectDate = new Date();
			}
			else
				throw new IllegalStateException("model already been connected"); // TODO reorder code
		}
	}
	
	public void disconnect()
	{
		synchronized(connectLock)
		{
			if(this.propertiesIfConnected!=null)
			{
				if(this.databaseIfConnected==null)
					throw new RuntimeException();
				if(this.itemCacheIfConnected==null)
					throw new RuntimeException();
				if(this.queryCacheIfConnected==null)
					throw new RuntimeException();
				if(this.connectDate==null)
					throw new RuntimeException();
		
				this.propertiesIfConnected = null;
				final Database db = this.databaseIfConnected;
				this.databaseIfConnected = null;
				
				types.disconnect();
				
				this.itemCacheIfConnected = null;
				this.queryCacheIfConnected = null;
				if(this.clusterSender!=null)
					this.clusterSender.close();
				this.clusterSender = null;
				if(this.clusterListener!=null)
					this.clusterListener.close();
				this.clusterListener = null;
				this.connectDate = null;
				
				db.close();
			}
			else
				throw new IllegalStateException("model not yet connected, use Model#connect"); // TODO reorder code
		}
	}
	
	public void flushSequences()
	{
		getDatabase().flushSequences();
	}
	
	private final void assertRevisionEnabled()
	{
		if(revisions==null)
			throw new IllegalArgumentException("revisions are not enabled");
	}

	public Revisions getRevisions()
	{
		return revisions;
	}
	
	void setRevisions(final Revisions revisions) // for test only, not for productive use !!!
	{
		assertRevisionEnabled();
		getDatabase().setRevisions(revisions); // do this first to fail early if not yet connected
		this.revisions = revisions;
	}

	public void revise()
	{
		assertRevisionEnabled();
		
		synchronized(reviseLock)
		{
			getDatabase().revise();
		}
	}

	public void reviseIfSupported()
	{
		if(revisions==null)
			return;
		
		revise();
	}

	public Map<Integer, byte[]> getRevisionLogs()
	{
		assertRevisionEnabled();
		return getDatabase().getRevisionLogs();
	}
	
	public ConnectProperties getProperties()
	{
		if(propertiesIfConnected==null)
			throw new IllegalStateException("model not yet connected, use Model#connect");

		return propertiesIfConnected;
	}
	
	Database getDatabase()
	{
		if(databaseIfConnected==null)
			throw new IllegalStateException("model not yet connected, use Model#connect");

		return databaseIfConnected;
	}
	
	ItemCache getItemCache()
	{
		if(itemCacheIfConnected==null)
			throw new IllegalStateException("model not yet connected, use Model#connect");

		return itemCacheIfConnected;
	}
	
	QueryCache getQueryCache()
	{
		if(queryCacheIfConnected==null)
			throw new IllegalStateException("model not yet connected, use Model#connect");

		return queryCacheIfConnected;
	}
	
	public Date getConnectDate()
	{
		return connectDate;
	}
	
	public List<Type<?>> getTypes()
	{
		return types.typeList;
	}
	
	public List<Type<?>> getTypesSortedByHierarchy()
	{
		return types.typeListSorted;
	}
	
	public List<Type<?>> getConcreteTypes()
	{
		return types.concreteTypeList;
	}

	/**
	 * @see Type#getID()
	 */
	public Type getType(final String id)
	{
		return types.getType(id);
	}
	
	/**
	 * @see Feature#getID()
	 */
	public Feature getFeature(final String id)
	{
		return types.getFeature(id);
	}
	
	public Date getInitializeDate()
	{
		return initializeDate;
	}
	
	public boolean supportsCheckConstraints()
	{
		return getDatabase().dsmfDialect.supportsCheckConstraints();
	}
	
	public boolean supportsSequences()
	{
		return getDatabase().supportsSequences;
	}
	
	/**
	 * Returns, whether the database can store empty strings.
	 * <p>
	 * If true, an empty string can be stored into a {@link StringField}
	 * like any other string via {@link FunctionField#set(Item,Object)}.
	 * A subsequent retrieval of that string via {@link FunctionField#get(Item)}
	 * returns an empty string.
	 * If false, an empty string stored into a {@link StringField} is
	 * converted to null, thus a subsequent retrieval of that string returns
	 * null.
	 * <p>
	 * Up to now, only Oracle does not support empty strings.
	 */
	public boolean supportsEmptyStrings()
	{
		return !getProperties().getDatabaseDontSupportEmptyStrings() && getDatabase().dialect.supportsEmptyStrings();
	}

	public boolean isDatabaseLogEnabled()
	{
		return getDatabase().log!=null;
	}
	
	/**
	 * Threshold time in milliseconds.
	 */
	public int getDatabaseLogThreshold()
	{
		final DatabaseLogConfig log = getDatabase().log;
		return log!=null ? log.threshold : 0;
	}
	
	public String getDatabaseLogSQL()
	{
		final DatabaseLogConfig log = getDatabase().log;
		return log!=null ? log.sql : null;
	}
	
	public void setDatabaseLog(final boolean enable, final int threshold, final String sql, final PrintStream out)
	{
		getDatabase().log = enable ? new DatabaseLogConfig(threshold, sql, out) : null;
	}
	
	/**
	 * @return the listener previously registered for this model
	 */
	DatabaseListener setDatabaseListener(final DatabaseListener listener)
	{
		return getDatabase().setListener(listener);
	}
	
	public void createSchema()
	{
		getDatabase().createSchema();
		clearCache();
	}

	public void createSchemaConstraints(final EnumSet<Constraint.Type> types)
	{
		getDatabase().createSchemaConstraints(types);
	}

	/**
	 * Checks the schema,
	 * whether the tables representing the types do exist.
	 * Issues a single database statement,
	 * that touches all tables and columns,
	 * that would have been created by
	 * {@link #createSchema()}.
	 * @throws RuntimeException
	 * 	if something is wrong with the database.
	 * 	TODO: use a more specific exception.
	 */
	public void checkSchema()
	{
		getDatabase().checkSchema(getCurrentTransaction().getConnection());
	}

	public void checkEmptySchema()
	{
		getDatabase().checkEmptySchema(getCurrentTransaction().getConnection());
	}

	public void dropSchema()
	{
		getDatabase().dropSchema();
		clearCache();
	}

	public void dropSchemaConstraints(final EnumSet<Constraint.Type> types)
	{
		getDatabase().dropSchemaConstraints(types);
	}

	public void tearDownSchema()
	{
		getDatabase().tearDownSchema();
		clearCache();
	}
	
	public void tearDownSchemaConstraints(final EnumSet<Constraint.Type> types)
	{
		getDatabase().tearDownSchemaConstraints(types);
	}

	public Schema getVerifiedSchema()
	{
		return getDatabase().makeVerifiedSchema();
	}

	public Schema getSchema()
	{
		return getDatabase().makeSchema();
	}

	/**
	 * Returns the item with the given ID.
	 * Always returns {@link Item#activeCopeItem() active} objects.
	 * @see Item#getCopeID()
	 * @throws NoSuchIDException if there is no item with the given id.
	 */
	public Item getItem(final String id)
			throws NoSuchIDException
	{
		final int pos = id.lastIndexOf(Item.ID_SEPARATOR);
		if(pos<=0)
			throw new NoSuchIDException(id, true, "no separator '" + Item.ID_SEPARATOR + "' in id");

		final String typeID = id.substring(0, pos);
		final Type type = getType(typeID);
		if(type==null)
			throw new NoSuchIDException(id, true, "type <" + typeID + "> does not exist");
		if(type.isAbstract)
			throw new NoSuchIDException(id, true, "type is abstract");
		
		final String idString = id.substring(pos+1);

		final long idNumber;
		try
		{
			idNumber = Long.parseLong(idString);
		}
		catch(NumberFormatException e)
		{
			throw new NoSuchIDException(id, e, idString);
		}

		if(idNumber<0)
			throw new NoSuchIDException(id, true, "must be positive");
		if(idNumber>=2147483648l)
			throw new NoSuchIDException(id, true, "does not fit in 31 bit");
		final int pk = (int)idNumber;
		
		final Item result = type.getItemObject(pk);
		if ( ! result.existsCopeItem() )
		{
			throw new NoSuchIDException(id, false, "item <"+idNumber+"> does not exist");
		}
		return result;
	}
	
	public List<ModificationListener> getModificationListeners()
	{
		synchronized(modificationListeners)
		{
			final int size = modificationListeners.size();
			if(size==0)
				return Collections.<ModificationListener>emptyList();
			
			// make a copy to avoid ConcurrentModificationViolations
			final ArrayList<ModificationListener> result = new ArrayList<ModificationListener>(size);
			int cleared = 0;
			for(final Iterator<WeakReference<ModificationListener>> i = modificationListeners.iterator(); i.hasNext(); )
			{
				final ModificationListener listener = i.next().get();
				if(listener==null)
				{
					i.remove();
					cleared++;
				}
				else
					result.add(listener);
			}
			
			if(cleared>0)
				this.modificationListenersCleared += cleared;
			
			return Collections.unmodifiableList(result);
		}
	}

	public int getModificationListenersCleared()
	{
		synchronized(modificationListeners)
		{
			return modificationListenersCleared;
		}
	}
	
	public void addModificationListener(final ModificationListener listener)
	{
		if(listener==null)
			throw new NullPointerException("listener");
		
		final WeakReference<ModificationListener> ref = new WeakReference<ModificationListener>(listener);
		synchronized(modificationListeners)
		{
			modificationListeners.add(ref);
		}
	}
	
	public void removeModificationListener(final ModificationListener listener)
	{
		if(listener==null)
			throw new NullPointerException("listener");

		synchronized(modificationListeners)
		{
			int cleared = 0;
			for(final Iterator<WeakReference<ModificationListener>> i = modificationListeners.iterator(); i.hasNext(); )
			{
				final ModificationListener l = i.next().get();
				if(l==null)
				{
					i.remove();
					cleared++;
				}
				else if(l==listener)
					i.remove();
			}
			if(cleared>0)
				this.modificationListenersCleared += cleared;
		}
	}
	
	public List<SequenceInfo> getSequenceInfo()
	{
		return getDatabase().getSequenceInfo();
	}
	
	public ItemCacheInfo[] getItemCacheInfo()
	{
		return getItemCache().getInfo();
	}
	
	public QueryCacheInfo getQueryCacheInfo()
	{
		return getQueryCache().getInfo();
	}
	
	public QueryCacheHistogram[] getQueryCacheHistogram()
	{
		return getQueryCache().getHistogram();
	}
	
	public Pool.Info getConnectionPoolInfo()
	{
		return getDatabase().connectionPool.getInfo();
	}
	
	public java.util.Properties getDatabaseInfo()
	{
		final DialectParameters db = getDatabase().dialectParameters;
		final java.util.Properties result = new java.util.Properties();
		result.setProperty("database.name", db.databaseProductName);
		result.setProperty("database.version", db.databaseProductVersion + ' ' + '(' + db.databaseMajorVersion + '.' + db.databaseMinorVersion + ')');
		result.setProperty("driver.name", db.driverName);
		result.setProperty("driver.version", db.driverVersion + ' ' + '(' + db.driverMajorVersion + '.' + db.driverMinorVersion + ')');
		return result;
	}

	public ClusterListenerInfo getClusterListenerInfo()
	{
		final ClusterListener clusterListener = this.clusterListener;
		if(clusterListener==null)
			return null;
		return clusterListener.getInfo();
	}
	
	// ----------------------- transaction
	
	/**
	 * @throws IllegalStateException
	 *    if there is already a transaction bound
	 *    to the current thread for this model
	 * @see #startTransaction(String)
	 */
	public Transaction startTransaction()
	{
		return startTransaction(null);
	}
	
	/**
	 * @param name
	 * 	a name for the transaction, useful for debugging.
	 * 	This name is used in {@link Transaction#toString()}.
	 * @throws IllegalStateException
	 *    if there is already a transaction bound
	 *    to the current thread for this model
	 * @see #startTransaction()
	 */
	public Transaction startTransaction(final String name)
	{
		getDatabase(); // ensure connected
		
		if(logTransactions)
			System.out.println("transaction start " + name);

		final Transaction previousTransaction = getCurrentTransactionIfBound();
		if(previousTransaction!=null)
		{
			final String previousName = previousTransaction.name;
			throw new IllegalStateException(
					"tried to start a new transaction " +
					(name!=null ? ("with name >" + name + '<') : "without a name") +
					", but there is already a transaction " + previousTransaction + ' ' +
					(previousName!=null ? ("with name >" + previousName + '<') : "without a name") +
					" started on " + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(previousTransaction.getStartDate()) +
					" bound to current thread");
		}
		
		final long id;
		final long startDate = System.currentTimeMillis();
		id = nextTransactionId.getAndIncrement();
		lastTransactionStartDate = startDate;
		
		final Transaction result = new Transaction(this, types.concreteTypeCount, id, name, startDate);
		setTransaction( result );
		synchronized(openTransactions)
		{
			openTransactions.add(result);
		}
		return result;
	}
	
	public long getNextTransactionId()
	{
		return nextTransactionId.get();
	}
	
	public Date getLastTransactionStartDate()
	{
		final long lastTransactionStartDate = this.lastTransactionStartDate;
		return lastTransactionStartDate!=Long.MIN_VALUE ? new Date(lastTransactionStartDate) : null;
	}
	
	public Transaction leaveTransaction()
	{
		Transaction tx = getCurrentTransaction();
		tx.unbindThread();
		setTransaction( null );
		return tx;
	}
	
	public void joinTransaction( Transaction tx )
	{
		if ( hasCurrentTransaction() )
			throw new RuntimeException("there is already a transaction bound to current thread");
		setTransaction(tx);
	}
	
	public boolean hasCurrentTransaction()
	{
		return getCurrentTransactionIfBound()!=null;
	}

	/**
	 * Returns the transaction for this model,
	 * that is bound to the currently running thread.
	 * @throws IllegalStateException if there is no cope transaction bound to current thread
	 * @see Thread#currentThread()
	 */
	public Transaction getCurrentTransaction()
	{
		final Transaction result = getCurrentTransactionIfBound();
		if(result==null)
			throw new IllegalStateException("there is no cope transaction bound to this thread, see Model#startTransaction");
		assert result.assertBoundToCurrentThread();
		return result;
	}
	
	private Transaction getCurrentTransactionIfBound()
	{
		final Transaction result = boundTransactions.get();
		assert result==null || result.assertBoundToCurrentThread();
		return result;
	}
	
	private void setTransaction(final Transaction transaction)
	{
		if(transaction!=null)
		{
			transaction.bindToCurrentThread();
			boundTransactions.set(transaction);
		}
		else
			boundTransactions.remove();
	}
	
	public void rollback()
	{
		commitOrRollback(true);
	}
	
	public void rollbackIfNotCommitted()
	{
		final Transaction t = getCurrentTransactionIfBound();
		if( t!=null )
			rollback();
	}
	
	public void commit()
	{
		commitOrRollback(false);
	}

	private void commitOrRollback(final boolean rollback)
	{
		final Transaction tx = getCurrentTransaction();
		
		if(logTransactions)
			System.out.println("transaction " + (rollback?"rollback":"commit") + ' ' + tx);
		
		synchronized(openTransactions)
		{
			openTransactions.remove(tx);
		}
		setTransaction(null);
		final boolean hadConnection = tx.commitOrRollback(rollback);
		
		if(hadConnection)
			if(rollback)
				transactionsRollbackWithConnection++;
			else
				transactionsCommitWithConnection++;
		else
			if(rollback)
				transactionsRollbackWithoutConnection++;
			else
				transactionsCommitWithoutConnection++;
	}

	/**
	 *	Returns true if the database supports READ_COMMITTED or any more strict transaction isolation level.
	 */
	boolean supportsReadCommitted()
	{
		return getDatabase().supportsReadCommitted;
	}
	
	/**
	 * Returns the collection of open {@link Transaction}s
	 * on this model.
	 * <p>
	 * Returns an unmodifiable snapshot of the actual data,
	 * so iterating over the collection on a live server cannot cause
	 * {@link java.util.ConcurrentModificationException}s.
	 */
	public Collection<Transaction> getOpenTransactions()
	{
		final Transaction[] result;
		synchronized(openTransactions)
		{
			result = openTransactions.toArray(new Transaction[openTransactions.size()]);
		}
		return Collections.unmodifiableCollection(Arrays.asList(result));
	}
	
	public TransactionCounters getTransactionCounters()
	{
		return new TransactionCounters(
				transactionsCommitWithoutConnection,
				transactionsCommitWithConnection,
				transactionsRollbackWithoutConnection,
				transactionsRollbackWithConnection);
	}
	
	public void clearCache()
	{
		getItemCache().clear();
		getQueryCache().clear();
	}
	
	/**
	 * @see ItemFunction#checkTypeColumn()
	 */
	public void checkTypeColumns()
	{
		for(final Type<?> t : getTypes())
		{
			checkTypeColumn(t.thisFunction);
			for(final Field a : t.getDeclaredFields())
				if(a instanceof ItemField)
					checkTypeColumn((ItemField)a);
		}
	}
	
	private static final void checkTypeColumn(final ItemFunction f)
	{
		if(f.needsCheckTypeColumn())
		{
			final int count = f.checkTypeColumn();
			if(count!=0)
				throw new RuntimeException("wrong type column for " + f + " on " + count + " tuples.");
		}
	}
	
	public void checkUnsupportedConstraints()
	{
		getDatabase().makeSchema().checkUnsupportedConstraints();
	}
	
	public boolean isClusterNetworkEnabled()
	{
		return this.clusterSender!=null;
	}
	
	public void pingClusterNetwork()
	{
		pingClusterNetwork(1);
	}
	
	public void pingClusterNetwork(final int count)
	{
		final ClusterSender clusterSender = this.clusterSender;
		if(clusterSender==null)
			throw new IllegalStateException("cluster network not enabled");
		clusterSender.ping(count);
	}
	
	private static final boolean skipIntern = Boolean.valueOf(System.getProperty("com.exedio.cope.skipIntern"));
	
	static
	{
		if(skipIntern)
			System.out.println("COPE: skipping String#intern()");
	}
	
	static final String intern(final String s)
	{
		if(skipIntern)
			return s;
		
		final String result = s.intern();
		//System.out.println("Model.intern >" + s + "< " + (result!=s ? "NEW" : "OLD"));
		return result;
	}
	
	public static final boolean isLoggingEnabled()
	{
		return Boolean.valueOf(System.getProperty("com.exedio.cope.logging"));
	}
	
	// ------------------- deprecated stuff -------------------
	
	/**
	 * @deprecated renamed to {@link #getItemCacheInfo()}.
	 */
	@Deprecated
	public ItemCacheInfo[] getCacheInfo()
	{
		return getItemCacheInfo();
	}
	
	/**
	 * @deprecated renamed to {@link #getQueryCacheHistogram()}.
	 */
	@Deprecated
	public QueryCacheHistogram[] getCacheQueryHistogram()
	{
		return getQueryCacheHistogram();
	}
	
	/**
	 * @deprecated renamed to {@link #getQueryCacheInfo()}.
	 */
	@Deprecated
	public QueryCacheInfo getCacheQueryInfo()
	{
		return getQueryCacheInfo();
	}
	
	/**
	 * @deprecated Use {@link #revise()} instead
	 */
	@Deprecated
	public void migrate()
	{
		revise();
	}

	/**
	 * @deprecated Use {@link #reviseIfSupported()} instead
	 */
	@Deprecated
	public void migrateIfSupported()
	{
		reviseIfSupported();
	}
	
	/**
	 * @deprecated Use {@link #getRevisionLogs()} instead
	 */
	@Deprecated
	public Map<Integer, byte[]> getMigrationLogs()
	{
		return getRevisionLogs();
	}
	
	/**
	 * @deprecated Use {@link #getModificationListenersCleared()} instead
	 */
	@Deprecated
	public int getModificationListenersRemoved()
	{
		return getModificationListenersCleared();
	}
	
	/**
	 * @deprecated renamed to {@link #connect(ConnectProperties)}.
	 */
	@Deprecated
	public void setPropertiesInitially(final ConnectProperties properties)
	{
		connect(properties);
	}
	
	/**
	 * @deprecated Use {@link #getItem(String)} instead
	 */
	@Deprecated
	public Item findByID(final String id) throws NoSuchIDException
	{
		return getItem(id);
	}
	
	/**
	 * @deprecated Use {@link #getType(String)} instead
	 */
	@Deprecated
	public Type findTypeByID(final String id)
	{
		return getType(id);
	}
	
	/**
	 * @deprecated Use {@link #getFeature(String)} instead
	 */
	@Deprecated
	public Feature findFeatureByID(final String id)
	{
		return getFeature(id);
	}
	
	/**
	 * @deprecated Use {@link #createSchema()} instead
	 */
	@Deprecated
	public void createDatabase()
	{
		createSchema();
	}

	/**
	 * @deprecated Use {@link #createSchemaConstraints(EnumSet)} instead
	 */
	@Deprecated
	public void createDatabaseConstraints(final EnumSet<Constraint.Type> types)
	{
		createSchemaConstraints(types);
	}

	/**
	 * @deprecated Use {@link #checkSchema()} instead
	 */
	@Deprecated
	public void checkDatabase()
	{
		checkSchema();
	}

	/**
	 * @deprecated Use {@link #checkEmptySchema()} instead
	 */
	@Deprecated
	public void checkEmptyDatabase()
	{
		checkEmptySchema();
	}

	/**
	 * @deprecated Use {@link #dropSchema()} instead
	 */
	@Deprecated
	public void dropDatabase()
	{
		dropSchema();
	}

	/**
	 * @deprecated Use {@link #dropSchemaConstraints(EnumSet)} instead
	 */
	@Deprecated
	public void dropDatabaseConstraints(final EnumSet<Constraint.Type> types)
	{
		dropSchemaConstraints(types);
	}

	/**
	 * @deprecated Use {@link #tearDownSchema()} instead
	 */
	@Deprecated
	public void tearDownDatabase()
	{
		tearDownSchema();
	}

	/**
	 * @deprecated Use {@link #tearDownSchemaConstraints(EnumSet)} instead
	 */
	@Deprecated
	public void tearDownDatabaseConstraints(final EnumSet<Constraint.Type> types)
	{
		tearDownSchemaConstraints(types);
	}
	
	/**
	 * @deprecated Use {@link #Model(Revisions, Type...)} and {@link Revisions#Revisions(int)}.
	 */
	@Deprecated
	public Model(final int revisionNumber, final Type... types)
	{
		this(new Revisions(revisionNumber), types);
	}
	
	/**
	 * @deprecated Use {@link #Model(Revisions, Type...)} and {@link Revisions#Revisions(Revision[])}.
	 */
	@Deprecated
	public Model(final Revision[] revisions, final Type... types)
	{
		this(new Revisions(revisions), types);
	}
}
